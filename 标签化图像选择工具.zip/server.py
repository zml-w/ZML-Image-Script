import os
import json
from flask import Flask, request, jsonify, send_file, Response
from flask_cors import CORS
from pathlib import Path
from PIL import Image, PngImagePlugin, ImageOps
from io import BytesIO

app = Flask(__name__)
CORS(app)

DEFAULT_TEXT_BLOCK_KEY = "comfy_text_block"
SUPPORTED_IMAGE_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff', '.webp']

def is_safe_path(base, user_path):
    try:
        base_real = Path(base).resolve()
        user_real = (Path(base) / user_path).resolve()
        return user_real.is_relative_to(base_real)
    except Exception:
        return False

@app.route('/list_images', methods=['GET'])
def list_images():
    custom_path_str = request.args.get('path', '')
    if not custom_path_str: return jsonify({"error": "缺少 'path' 参数"}), 400
    base_dir = Path(custom_path_str)
    if not base_dir.is_absolute(): return jsonify({"error": f"路径必须是绝对路径"}), 400
    if not base_dir.is_dir(): return jsonify({"error": f"路径不是有效文件夹: {custom_path_str}"}), 400

    image_files_list = []
    try:
        for root, _, files in os.walk(base_dir, followlinks=True):
            for file in files:
                if os.path.splitext(file)[1].lower() in SUPPORTED_IMAGE_EXTENSIONS:
                    subfolder = Path(root).relative_to(base_dir)
                    image_files_list.append({"filename": file, "subfolder": str(subfolder).replace("\\", "/")})
        image_files_list.sort(key=lambda x: os.path.join(x['subfolder'], x['filename']))
        return jsonify({"files": image_files_list, "base_path_display": str(base_dir)})
    except Exception as e:
        return jsonify({"error": f"扫描文件夹时出错: {str(e)}"}), 500

@app.route('/extract_text', methods=['POST'])
def extract_text():
    data = request.get_json()
    if not data: return jsonify({"error": "无效的请求"}), 400
    file_list = data.get('files', [])
    base_path_str = data.get('base_path', '')
    if not base_path_str or not Path(base_path_str).is_dir(): return jsonify({"error": "无效的基准路径"}), 400
    base_dir = Path(base_path_str)
    text_blocks = []
    for item in file_list:
        filename, subfolder = item.get("filename", ""), item.get("subfolder", "")
        if not is_safe_path(base_dir, Path(subfolder) / filename): continue
        image_path = base_dir / subfolder / filename
        if not image_path.is_file(): continue
        try:
            with Image.open(image_path) as img:
                if hasattr(img, 'text') and DEFAULT_TEXT_BLOCK_KEY in img.text:
                    text_blocks.append(img.text[DEFAULT_TEXT_BLOCK_KEY])
        except Exception as e: print(f"读取图片 '{image_path}' 失败: {e}")
    return jsonify({"text_content": "\n\n---\n\n".join(text_blocks)})

def get_image_path_from_req(req_args):
    filename = req_args.get('filename')
    subfolder = req_args.get('subfolder', '')
    base_path_str = req_args.get('path', '')
    if not all([filename, base_path_str]): return None, "参数缺失"
    base_dir = Path(base_path_str)
    if not base_dir.is_dir(): return None, "基准路径无效"
    if not is_safe_path(base_dir, Path(subfolder) / filename): return None, "不允许的路径"
    return (base_dir / subfolder / filename).resolve(), None

@app.route('/get_single_text_block', methods=['GET'])
def get_single_text_block():
    image_path, error = get_image_path_from_req(request.args)
    if error: return jsonify({"error": error}), 400
    if not image_path.is_file(): return jsonify({"error": "图片未找到"}), 404
    
    content = ""
    try:
        with Image.open(image_path) as img:
            if hasattr(img, 'text') and DEFAULT_TEXT_BLOCK_KEY in img.text:
                content = img.text[DEFAULT_TEXT_BLOCK_KEY]
    except Exception as e:
        return jsonify({"error": f"读取图片失败: {e}"}), 500
    return jsonify({"text_content": content})

@app.route('/write_text_block', methods=['POST'])
def write_text_block():
    data = request.get_json()
    if not data: return jsonify({"error": "无效请求"}), 400
    filename, subfolder, base_path_str, new_text = data.get('filename'), data.get('subfolder', ''), data.get('base_path', ''), data.get('text_content', '')
    if not all([filename, base_path_str]): return jsonify({"error": "参数缺失"}), 400
    if Path(filename).suffix.lower() != '.png': return jsonify({"error": "目前仅支持向PNG文件写入文本块"}), 400
    base_dir = Path(base_path_str)
    if not is_safe_path(base_dir, Path(subfolder) / filename): return jsonify({"error": "不允许的路径"}), 403
    image_path = (base_dir / subfolder / filename).resolve()
    if not image_path.is_file(): return jsonify({"error": "图片未找到"}), 404
    try:
        with Image.open(image_path) as img:
            img.load()
            metadata = PngImagePlugin.PngInfo()
            if img.info:
                for key, value in img.info.items():
                    if key != DEFAULT_TEXT_BLOCK_KEY: metadata.add_text(str(key), str(value))
            if new_text: metadata.add_text(DEFAULT_TEXT_BLOCK_KEY, new_text, zip=True)
            img.save(image_path, pnginfo=metadata)
    except Exception as e:
        return jsonify({"error": f"写入文件失败: {e}"}), 500
    return jsonify({"success": True, "message": "写入成功"})

def serve_image_file(is_thumb):
    image_path, error = get_image_path_from_req(request.args)
    if error: return Response(error, status=400)
    if not image_path.is_file(): return Response("图片未找到", status=404)
    try:
        if not is_thumb: return send_file(image_path)
        else:
            with Image.open(image_path) as img:
                img = ImageOps.exif_transpose(img).convert('RGB')
                img.thumbnail((120, 120))
                buffer = BytesIO()
                img.save(buffer, format="JPEG", quality=85)
                buffer.seek(0)
                return send_file(buffer, mimetype='image/jpeg')
    except Exception as e: return Response(f"提供图片失败: {e}", status=500)

@app.route('/view_image')
def view_image(): return serve_image_file(is_thumb=False)
@app.route('/view_image_thumb')
def view_image_thumb(): return serve_image_file(is_thumb=True)

if __name__ == '__main__':
    print("ZML 图像加载器本地服务已启动...")
    print(f"服务正在监听: http://127.0.0.1:6868")
    app.run(host='127.0.0.1', port=6868, debug=False)